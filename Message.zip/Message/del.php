<?php
header('Content-Type:text/html;charset=utf-8');
$link = mysqli_connect('localhost','root','','csx');
mysqli_set_charset($link, 'utf8');
$id=$_GET['id'];
$sql="delete from `lyb` where `id`= $id ";
$a=mysqli_query($link,$sql);
if ($a) {
	echo '<script>alert("删除成功");location.href="me.php"
		</script>';
}

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="a1.css" rel="stylesheet" type="text/css">
    <link href="js/bootstrap.css" rel="stylesheet">
    <title>我的</title>
    <style>
        .login {
            margin-right: 5px;
        }

        .span {
            color: green;
        }
    </style>
</head>
<body>
<?php
session_start();

echo '<div class="yh">';
if (!empty($_SESSION['user'])) {
    echo '<span class="login span">' . $_SESSION['user'] . '<span> ' . '  ' . '<a href="./me.php" class="btn btn-primary login">我的主页</a>' . '  ' . '<a href="./logout.php" class="btn btn-primary login">注销</a>';

}
echo '</div>';
?>
<div class="content">
    <div class="panel panel-default">
        <div class="panel-body">
            我的发表:
        </div>
    </div>
    <ul>

        <?php
        date_default_timezone_set('PRC');
        $user = $_SESSION['user'];
        $link = mysqli_connect('localhost', 'root', '', 'csx');

        mysqli_set_charset($link, 'utf8');

        $sql = "select * from lyb where name='{$user}' order by time desc";

        $res = mysqli_query($link, $sql);

        $arr = [];
        if ($res) {
            $arr = mysqli_fetch_all($res, 1);
        }

        mysqli_close($link);

        foreach ($arr as $v) {

            ?>
            <li class="item">
                <p class="name"><?= $v['name'] ?><a href="del.php?id=<?php echo $v['id'] ?>" style="float: right;"
                                                    class="btn btn-primary">删除</a></p>
                <p class="con"><?= $v['content'] ?><a href="edita.php?id=<?php echo $v['id'] ?>" style="float: right;"
                                                      class="btn btn-primary">修改</a></p>
                <p class="time"><?= date('Y-m-d H:i:s', $v['time']) ?></p>
            </li>

        <?php } ?>
    </ul>
</div>
</body>
</html>
<?php
header('Content-Type:text/html;charset=utf-8');
session_start();
unset($_SESSION['user']);
echo '<script>alert("已注销登录");location.href="login.html.php"
		</script>';
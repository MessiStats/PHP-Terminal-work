<?php
session_start();
header('Content-Type:text/html;charset=utf-8');

if (empty($_POST['user'])) {
    echo '<script>
			alert("用户名不能为空！");location.href="login.html.php";
		</script>';
}

if (empty($_POST['password'])) {
    echo '<script>
			alert("密码不能为空！");location.href="login.html.php";
		</script>';
    exit;
}


$user = $_POST['user'];
$pwd  = $_POST['password'];

$link = mysqli_connect('localhost', 'root', '', 'csx');

$row = [];

$sql = "select * from yhb where user='{$user}'";

$res = mysqli_query($link, $sql);

if ($res) {
    $row = mysqli_fetch_assoc($res);
}

if (md5($pwd) == $row['password']) {

    echo '登录成功，3秒后跳转。。。<meta http-equiv="refresh" content="3;url=./index.php">';
    $_SESSION['user'] = $user;

} else {

    echo '用户名或密码错误，3秒后跳转。。。<meta http-equiv="refresh" content="3;url=./login.html.php">';

}

mysqli_close($link); 

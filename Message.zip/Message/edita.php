<!DOCTYPE html>
<html>
<head>
	<title>修改我的内容</title>
</head>
<meta charset="utf-8">
<link href="a1.css" rel="stylesheet" type="text/css">
<link href="js/bootstrap.css" rel="stylesheet">
<style>
    .fom1 textarea{
        border: 5px solid #337ab7;
        width: 750px;
        height: 200px;
        background: whitesmoke;
    }
    .login {
        margin-right: 5px;
    }
    .span{
        color: green;
    }
</style>
<body>
<?php
session_start();

	echo '<div class="yh">';
	if (!empty($_SESSION['user'])) {
        echo '<span class="login span">' . $_SESSION['user'] . '<span> ' . '  ' . '<a href="./me.php" class="btn btn-primary login">我的主页</a>' . '  ' . '<a href="./logout.php" class="btn btn-primary login">注销</a>';

    }
	echo '</div>';
?>
<?php
	$id=$_GET['id'];
	date_default_timezone_set('PRC');

	$link = mysqli_connect('localhost','root','','csx');

	mysqli_set_charset($link,'utf8');

	$sql = "select * from lyb where  id=$id";

	$res = mysqli_query($link,$sql);
	$arr = [];
	if ($res) {
		$arr = mysqli_fetch_array($res);
	}	
	mysqli_close($link);


		?>	

<div class="content">
    <div class="panel panel-default">
        <div class="panel-body">
            修改的内容:
        </div>
    </div>
		<form class="fom1" action="./edit.php?id=<?php echo $id ?>" method="post">
			<textarea name="content"  ><?php echo $arr['content']; ?></textarea>
			<button class="btn btn-primary">修改</button>
		</form>
</div>
</body>
</html>
<?php
header('Content-Type:text/html;charset:utf-8');

session_start();

if (empty($_POST['user'])) {
	echo '<script>
			alert("用户名不能为空！");location.href="register.html.php";
		</script>';
}

if (empty($_POST['password'])) {
	echo '<script>
			alert("密码不能为空！");location.href="register.html.php";
		</script>';
}

if (empty($_POST['password2'])) {
	echo '<script>
			alert("请输入两次密码！");location.href="register.html.php";
		</script>';
}

if ($_POST['password']!=$_POST['password2']) {
	echo '<script>
			alert("您输入的两次密码不一致，请重新确认密码！");location.href="register.html.php";
		</script>';
	
}

if(strcasecmp($_POST['check'],$_SESSION['check'])){
	echo '<script>
			alert("验证码输入错误");location.href="register.html.php";
		</script>';
	
}
$user = $_POST['user'];

$_POST['time'] = time();

$link = mysqli_connect('localhost', 'root', '', 'csx');
mysqli_set_charset($link, 'utf8');
$row = [];
$sql1 = "select * from yhb where user='{$user}'";

$res1 = mysqli_query($link,$sql1);

if ($res1) {
	$row = mysqli_fetch_assoc($res1);
}

if ($user==$row['user']) {
	echo '<script>
			alert("用户名已经被使用，请重新选取用户名！");location.href="register.html.php"
		</script>';
		exit;
}

$pawd = md5($_POST['password']);

$sql = "insert into yhb values(null, '{$_POST['user']}', '{$pawd}')";

$res = mysqli_query($link, $sql);

if ($res1) {
	$row = mysqli_fetch_assoc($res1);
}
if ($res) {
	echo '<script>
			alert("注册成功");location.href="login.html.php"
		</script>';
} else {
	echo '<script>
			alert("注册失败");location.href="register.html.php"
		</script>';
}

mysqli_close($link);
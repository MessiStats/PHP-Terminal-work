<?php
header('Content-Type:text/html;charset=utf-8');
$content=$_POST['content'];
$id=$_GET['id'];
$link = mysqli_connect('localhost','root','','csx');

	mysqli_set_charset($link,'utf8');
	$sql = 'update lyb set `content`='. "'$content'". 'where id = '.$id;
	$res = mysqli_query($link,$sql);
	var_dump($res);
	if ($res) {
		echo '<script>alert("修改成功");location.href="me.php"
		</script>';
	}
  
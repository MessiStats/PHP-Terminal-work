<?php
header('Content-Type:text/html;charset=utf-8');
session_start();
if (empty($_SESSION['user'])) {
	echo '<script>alert("未登录");location.href="index.php"
		</script>';
		 exit;
}

echo '<meta charset="utf-8">';

if (empty($_POST['content'])) {
	echo '留言内容不能为空,2秒后跳转...<meta http-equiv="refresh" content="2;url=add.html.php">';
	exit;
}

$_POST['time'] = time();

$link = mysqli_connect('localhost', 'root', '', 'csx');

mysqli_set_charset($link, 'utf8');

$sql = "insert into lyb values(null, '{$_SESSION['user']}', '{$_POST['content']}', '{$_POST['time']}')";

$res = mysqli_query($link, $sql);

if ($res) {
	echo '<script>alert("发表成功");location.href="index.php"
		</script>';
} else {
	echo '<script>alert("发表失败");location.href="index.php"</script>';
}

mysqli_close($link);
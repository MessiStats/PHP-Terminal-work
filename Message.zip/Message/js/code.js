	
	function check(){
		var v1=$("#hiddent_val").text();
		v1 = v1*1;
		var v2=$("#check_val").val();
		v2 = v2*1;
		if (v1==v2) {
			alert('ok');
		}else{
			alert('flase');
		}
	}
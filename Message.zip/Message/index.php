<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>留言板</title>
    <link href="a1.css" rel="stylesheet" type="text/css">
    <link href="./js/bootstrap.css" rel="stylesheet" type="text/css">
    <style>
        .footer {
            margin-left: 250px;
        }

        .footer a {
            margin-left: 20px;
        }

        .fom1 textarea {
            border: 5px solid #337ab7;
            width: 750px;
            height: 200px;
            background: whitesmoke;
        }

        .login {
            margin-right: 5px;
        }
        .span{
            color: green;
        }
    </style>
</head>

<body>
<?php
session_start();
// $_SESSION['user'] = 'csx';
// echo $_SESSION['user'];
echo '<div class="yh">';
if (!empty($_SESSION['user'])) {
    echo '<span class="login span">' . $_SESSION['user'] . '<span> ' . '  ' . '<a href="./me.php" class="btn btn-primary login">我的主页</a>' . '  ' . '<a href="./logout.php" class="btn btn-primary login">注销</a>';
} else {
    echo '<a href="./login.html.php" class="btn btn-primary" style="margin-right: 10px">未登录</a>';
}
echo '</div>';
?>
<div class="content">
    <!--		<img src="./img/1.png" width="750px" />-->
    <form class="fom1" action="./add.php" method="post">
        <!-- <input type="text" name="name" placeholder="请输入昵称"/> -->

        <textarea name="content" placeholder="请输入内容"></textarea>
        <button class="btn btn-primary">发表</button>
    </form>
    <div class="panel panel-default">
        <div class="panel-body">
            最新评论:
        </div>
    </div>

    <ul>

        <?php

        date_default_timezone_set('PRC');

        $link = mysqli_connect('localhost', 'root', '', 'csx');

        mysqli_set_charset($link, 'utf8');
        //$sql = 'select * from lyb order by time desc ';


        //-----------------------------------------------------------------------
        //总页数
        $countsql = "select count(*) from lyb";
        $res      = mysqli_query($link, $countsql);
        $arr      = [];
        if ($res) {
            $arr = mysqli_fetch_all($res, 1);
        }
        $count = $arr[0]['count(*)'];


        //--------------------------------------------------------
        if (!isset($page)) {
            $page = 0;
        }

        if (isset($_GET['head'])) {
            $page = $_GET['head'];
        }
        //下一页
        if (isset($_GET['next'])) {
            $page = $_GET['next'] + 3;
            if ($page > (intval($count / 3)) * 3) {
                $page = (intval($count / 3)) * 3;
            }
        }
        //上一页
        if (isset($_GET['before'])) {
            if ($_GET['before'] == 0) {
                $page = 0;
            } else {
                $page = $_GET['before'] - 3;
            }
        }
        //尾页
        if (isset($_GET['end'])) {
            $page = (intval($count / 3)) * 3;
            if ($page < 0) {
                $page = 0;
            }
        }

        $sql = 'select * from lyb order by time desc limit ' . $page . ',3';


        //------------------------------------------------------------------


        $res = mysqli_query($link, $sql);

        $arr = [];
        if ($res) {
            $arr = mysqli_fetch_all($res, 1);
        }

        mysqli_close($link);

        foreach ($arr as $v) {

            ?>
            <li class="item">
                <p class="name"><?= $v['name'] ?></p>
                <p class="con"><?= $v['content'] ?></p>
                <p class="time"><?= date('Y-m-d H:i:s', $v['time']) ?></p>
            </li>

        <?php } ?>

    </ul>
    <div class="footer" style="margin-bottom:50px">
        <a href="http://localhost/tencent/index.php?head=0" class="btn btn-primary">首页</a>
        <a href="http://localhost/tencent/index.php?before=<?php echo $page; ?>">上一页</a>
        <a href="http://localhost/tencent/index.php?next=<?php echo $page ?>">下一页</a>
        <a href="http://localhost/tencent/index.php?end=end" class="btn btn-primary">尾页</a>
    </div>
</div>

</body>

</html>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>登录</title>
    <link rel="stylesheet" href="js/bootstrap.css">
    <link rel="stylesheet" href="register/css/style.css">
	<style type="text/css">
		body {
			background: #eee;
			margin: 0;
		}

		.container {
			width: 320px;
			height: 357px;
			margin: 30px auto 0;
			text-align: center;
		}

		.form {
			width: 290px;
			margin: 20px auto 0;
		}

		.form input {
			width: 275px;
			height: 45px;
			padding: 0;
			padding-left: 15px;
			resize: none;
			border: 0;
			border-radius: 4px;
			outline: 0;
		}

		.form button {
			width: 290px;
			background: #146fdf;
			height: 44px;
			border: 0;
			color: #fff;
			margin-top: 15px;
			font-size: 16px;
			border-radius: 4px;
		}

		.fom1 a {
			color: #246183;
			text-decoration: none;
			margin-top: 20px;
			font-size: 14px;
		}

		.fom1 a:hover {
			color: red;
		}
	</style>
</head>

<body>
    <!-- contact-form -->
    <div class="message warning">
        <div class="inset">
            <div class="login-head">
                <h1>Login Form</h1>
                <div class="alert-close"> </div>
            </div>
            <form action="./login.php" method="post">
                <li>
                    <input type="text" class="text" value="Username" name="user" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Username';}"><a href="#" class=" icon user"></a>
                </li>
                <div class="clear"> </div>
                <li>
                    <input type="password" value="Password" name="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}"> <a href="#" class="icon lock"></a>
                </li>
                <div class="clear"> </div>
                <div class="submit">
                    <input type="submit" value="登录" >
<!--                    <button class="btn btn-primary">登录</button>-->
                    <h4><a href="./register.html.php">注册新账号</a></h4>
                    <div class="clear">  </div>
                </div>

            </form>
        </div>
    </div>
    <div class="clear"> </div>
    <!--- footer --->
    <div class="footer">
        <p style="color: #6C496F;">Copyright &copy; 2019.</p>
    </div>

</body>

</html>